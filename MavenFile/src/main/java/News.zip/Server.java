package News;

import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.google.gson.Gson;

public class Server {
//	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
//	static final String DB_URL = "jdbc:mysql://192.168.0.41:3306/IyHyeon";
//
//	static final String USERNAME = "root";
//	static final String PASSWORD = "swhacademy!";
	static Input i = null;

	public static void main(String[] args) throws IOException {
		ArrayList<String> b = new ArrayList<String>();
		H_query q = new H_query();
		Anno_query anno = new Anno_query();
		ServerSocket server = null;
		Socket sock = null;
		System.out.println(". . . Waiting Connect . . .");
		server = new ServerSocket(10001);
		int i1 = 0;
//		InetAddress address = sock.getInetAddress();
//		System.out.println(address + "로부터 접속했습니다.");
		while (true) {

			try {
				sock = server.accept();
				if (b.size() == 52) {
					System.out.println();
				}
				InputStream in = sock.getInputStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				i = new Gson().fromJson(br.readLine(), Input.class);
				b.add(i.id);
				System.out.println(b.size());
				System.out.println(i.id);
				anno.infoSave(i.category,i.id, i.title, i.script, i.date);
			} catch (Exception e) {
//				System.out.println(e);
			} finally {
				sock.close();
			}
		}

	}
}
