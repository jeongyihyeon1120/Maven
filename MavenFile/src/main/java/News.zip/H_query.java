package News;

import javax.print.DocFlavor.STRING;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import hibernate.HibernateUtil;
import hibernate.SWHAcademy12;

public class H_query {
	public void H_Query(String title, String script, int id){
		SessionFactory sessionFactory = Hibernate.getSessionFactory();
        NewsDoc user = new NewsDoc();
        user.setId(id);
        user.setTitle(title);
        user.setScript(script);
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.save(user);
        session.getTransaction().commit();
        System.out.println("Insert completed");

//        session.beginTransaction();
//        SWHAcademy myuser = (SWHAcademy)session.get(SWHAcademy.class, "key");
//        System.out.println("name:"+myuser.getName());
//        myuser.setTitle("hi");
//        session.getTransaction().commit();
        
        session.close();
        sessionFactory.close();
    }
}